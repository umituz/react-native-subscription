import React from "react";
import { View, TouchableOpacity, StyleSheet } from "react-native";
import { AtomicText, AtomicSpinner } from "@umituz/react-native-design-system/atoms";
import { useAppDesignTokens } from "@umituz/react-native-design-system/theme";
import type { PaywallTranslations, PaywallLegalUrls } from "../entities/types";

interface PaywallFooterProps {
  translations: PaywallTranslations;
  legalUrls: PaywallLegalUrls;
  isProcessing: boolean;
  onPurchase?: () => void | Promise<void>;
  onRestore?: () => Promise<void | boolean>;
  onLegalClick: (url: string | undefined) => void;
  purchaseButtonText?: string;
  isTablet?: boolean;
  isSmallDevice?: boolean;
}

export const PaywallFooter: React.FC<PaywallFooterProps> = React.memo(({
  translations,
  legalUrls,
  isProcessing,
  onPurchase,
  onRestore,
  onLegalClick,
  purchaseButtonText,
  isTablet = false,
  isSmallDevice = false,
}) => {
  const tokens = useAppDesignTokens();

  // Device-based sizing
  const buttonHeight = React.useMemo(() => {
    if (isTablet) return 64; // Larger button on tablet
    if (isSmallDevice) return 52; // Slightly smaller on small phones
    return 56; // Standard size
  }, [isTablet, isSmallDevice]);

  const fontSize = React.useMemo(() => {
    if (isTablet) return 19;
    if (isSmallDevice) return 16;
    return 17;
  }, [isTablet, isSmallDevice]);

  const paddingVertical = React.useMemo(() => {
    if (isTablet) return 20;
    if (isSmallDevice) return 12;
    return 16;
  }, [isTablet, isSmallDevice]);

  return (
    <View style={footerStyles.container}>
      {/* Purchase Button - Device-responsive */}
      {onPurchase && (
        <TouchableOpacity
          onPress={onPurchase}
          disabled={isProcessing}
          activeOpacity={0.8}
          style={[
            footerStyles.purchaseButton,
            {
              backgroundColor: tokens.colors.primary,
              height: buttonHeight,
              paddingVertical: paddingVertical,
            },
            isProcessing && footerStyles.buttonDisabled,
          ]}
        >
          {isProcessing ? (
            <View style={footerStyles.loadingContainer}>
              <AtomicSpinner size="sm" />
            </View>
          ) : (
            <AtomicText style={[footerStyles.purchaseButtonText, { color: tokens.colors.textPrimary, fontSize }]}>
              {purchaseButtonText || translations.purchaseButtonText}
            </AtomicText>
          )}
        </TouchableOpacity>
      )}

      {/* Restore Link - Device-spaced */}
      {onRestore && (
        <TouchableOpacity
          onPress={onRestore}
          disabled={isProcessing}
          activeOpacity={0.6}
          style={[footerStyles.restoreButton, { marginTop: isTablet ? 16 : 8 }]}
        >
          <AtomicText style={[footerStyles.restoreText, { color: tokens.colors.textSecondary }]}>
            {translations.restoreButtonText}
          </AtomicText>
        </TouchableOpacity>
      )}

      {/* Legal Links - Responsive spacing */}
      <View style={footerStyles.legalContainer}>
        {legalUrls.termsUrl && (
          <TouchableOpacity
            onPress={() => onLegalClick(legalUrls.termsUrl)}
            activeOpacity={0.6}
          >
            <AtomicText style={[footerStyles.legalText, { color: tokens.colors.textTertiary }]}>
              {translations.termsOfServiceText}
            </AtomicText>
          </TouchableOpacity>
        )}
        {legalUrls.privacyUrl && (
          <>
            <AtomicText style={footerStyles.legalSeparator}> • </AtomicText>
            <TouchableOpacity
              onPress={() => onLegalClick(legalUrls.privacyUrl)}
              activeOpacity={0.6}
            >
              <AtomicText style={[footerStyles.legalText, { color: tokens.colors.textTertiary }]}>
                {translations.privacyText}
              </AtomicText>
            </TouchableOpacity>
          </>
        )}
      </View>
    </View>
  );
});

// Modern footer styles
const footerStyles = StyleSheet.create({
  container: {
    width: '100%',
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 12,
  },
  purchaseButton: {
    width: '100%',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  loadingContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  purchaseButtonText: {
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  restoreButton: {
    alignItems: 'center',
  },
  restoreText: {
    fontWeight: '500',
    textDecorationLine: 'underline',
  },
  legalContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  legalText: {
    lineHeight: 16,
  },
  legalSeparator: {
    color: 'rgba(255, 255, 255, 0.4)',
    marginHorizontal: 4,
  },
});
