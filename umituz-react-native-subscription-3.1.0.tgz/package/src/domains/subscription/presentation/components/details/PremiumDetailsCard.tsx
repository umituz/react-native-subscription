import React from "react";
import { View } from "react-native";
import { AtomicText } from "@umituz/react-native-design-system/atoms";
import { useAppDesignTokens } from "@umituz/react-native-design-system/theme";
import { DetailRow } from "./DetailRow";
import { CreditRow } from "./CreditRow";
import { styles } from "./PremiumDetailsCard.styles";
import type { PremiumDetailsCardProps } from "./PremiumDetailsCardTypes";
import { PremiumDetailsCardHeader } from "./PremiumDetailsCardHeader";
import { PremiumDetailsCardActions } from "./PremiumDetailsCardActions";
import { shouldHighlightExpiration } from "../../../../subscription/utils/expirationHelpers";
import { hasItems } from "../../../../../shared/utils/arrayUtils";

export type { CreditInfo, PremiumDetailsTranslations, PremiumDetailsCardProps } from "./PremiumDetailsCardTypes";

export const PremiumDetailsCard: React.FC<PremiumDetailsCardProps> = React.memo(({
  statusType,
  isPremium,
  expirationDate,
  purchaseDate,
  daysRemaining,
  credits,
  translations,
  onManageSubscription,
  onUpgrade,
}) => {
  const tokens = useAppDesignTokens();
  const showCredits = isPremium && hasItems(credits);

  return (
    <View style={[styles.card, { backgroundColor: tokens.colors.surface }]}>
      {(isPremium || showCredits) && <PremiumDetailsCardHeader statusType={statusType} translations={translations} />}


      {isPremium && (
        <View style={styles.detailsSection}>
          {expirationDate && (
            <DetailRow label={translations.expiresLabel} value={expirationDate} highlight={shouldHighlightExpiration(daysRemaining)} />
          )}
          {purchaseDate && <DetailRow label={translations.purchasedLabel} value={purchaseDate} />}
        </View>
      )}

      {showCredits && credits && (
        <View style={[styles.creditsSection, { borderTopColor: tokens.colors.border }]}>
          {translations.creditsTitle && (
            <AtomicText type="labelMedium" style={[styles.sectionTitle, { color: tokens.colors.textPrimary }]}>
              {translations.creditsTitle}
            </AtomicText>
          )}
          {credits.map((credit) => (
            <CreditRow
              key={credit.id}
              label={credit.label}
              current={credit.current}
              total={credit.total}
              remainingLabel={translations.remainingLabel}
            />
          ))}
        </View>
      )}

      <PremiumDetailsCardActions
        isPremium={isPremium}
        onManageSubscription={onManageSubscription}
        onUpgrade={onUpgrade}
        translations={translations}
      />
    </View>
  );
});
