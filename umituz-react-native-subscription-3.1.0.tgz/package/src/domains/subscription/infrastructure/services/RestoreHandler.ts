import Purchases from "react-native-purchases";
import type { RestoreResult } from "../../../../shared/application/ports/IRevenueCatService";
import {
  RevenueCatRestoreError,
  RevenueCatInitializationError,
  RevenueCatNetworkError,
} from "../../../revenuecat/core/errors/RevenueCatError";
import type { RevenueCatConfig } from "../../../revenuecat/core/types/RevenueCatConfig";
import {
  getRawErrorMessage,
  getErrorCode,
  isNetworkError,
  isInvalidCredentialsError,
} from "../../../revenuecat/core/types/RevenueCatTypes";
import { notifyRestoreCompleted } from "../utils/PremiumStatusSyncer";

interface RestoreHandlerDeps {
  config: RevenueCatConfig;
  isInitialized: () => boolean;
}

export async function handleRestore(deps: RestoreHandlerDeps, userId: string): Promise<RestoreResult> {
  if (!deps.isInitialized()) throw new RevenueCatInitializationError();

  try {
    const customerInfo = await Purchases.restorePurchases();
    const entitlement = customerInfo.entitlements.active[deps.config.entitlementIdentifier];
    const isPremium = !!entitlement;
    const productId = entitlement?.productIdentifier ?? null;

    await notifyRestoreCompleted(deps.config, userId, isPremium, customerInfo);

    return { success: true, isPremium, productId, customerInfo };
  } catch (error) {
    // Network error - throw specific error type
    if (isNetworkError(error)) {
      throw new RevenueCatNetworkError(
        "Network error during restore. Please check your internet connection and try again.",
        error instanceof Error ? error : undefined
      );
    }

    // Invalid credentials - configuration error
    if (isInvalidCredentialsError(error)) {
      throw new RevenueCatRestoreError(
        "App configuration error. Please contact support.",
        error instanceof Error ? error : undefined
      );
    }

    // Generic error with code
    const errorCode = getErrorCode(error);
    const errorMessage = getRawErrorMessage(error);
    const enhancedMessage = errorCode
      ? `${errorMessage} (Code: ${errorCode})`
      : errorMessage;

    throw new RevenueCatRestoreError(
      enhancedMessage,
      error instanceof Error ? error : undefined
    );
  }
}
