import type { Firestore, DocumentReference } from "@umituz/react-native-firebase";
import { BaseRepository } from "@umituz/react-native-firebase";
import type { CreditsConfig, CreditsResult, DeductCreditsResult } from "../core/Credits";
import type { PurchaseSource } from "../core/UserCreditsDocument";
import type { RevenueCatData } from "../../revenuecat/core/types/RevenueCatData";
import { deductCreditsOperation } from "../application/DeductCreditsCommand";
import { refundCreditsOperation } from "../application/RefundCreditsCommand";
import { PURCHASE_TYPE, type PurchaseType } from "../../subscription/core/SubscriptionConstants";
import { requireFirestore, buildDocRef, type CollectionConfig } from "../../../shared/infrastructure/firestore/collectionUtils";
import { fetchCredits, checkHasCredits, documentExists } from "./operations/CreditsFetcher";
import { syncExpiredStatus, syncPremiumMetadata, createRecoveryCreditsDocument } from "./operations/CreditsWriter";
import type { SubscriptionMetadata } from "../../subscription/core/types/SubscriptionMetadata";
import { initializeCreditsWithRetry } from "./operations/CreditsInitializer";
import { CreditLimitService } from "../domain/services/CreditLimitService";

export class CreditsRepository extends BaseRepository {
  private creditLimitService: CreditLimitService;

  constructor(
    private config: CreditsConfig,
    creditLimitService?: CreditLimitService
  ) {
    super(config.collectionName);
    // Allow dependency injection or create default instance
    this.creditLimitService = creditLimitService ?? new CreditLimitService(config);
  }

  private getCollectionConfig(): CollectionConfig {
    return {
      collectionName: this.config.collectionName,
      useUserSubcollection: this.config.useUserSubcollection,
    };
  }

  private getRef(db: Firestore, userId: string): DocumentReference {
    const config = this.getCollectionConfig();
    return buildDocRef(db, userId, "balance", config);
  }

  async getCredits(userId: string): Promise<CreditsResult> {
    const db = requireFirestore();
    return fetchCredits(this.getRef(db, userId));
  }

  async initializeCredits(
    userId: string,
    purchaseId: string,
    productId: string,
    source: PurchaseSource,
    revenueCatData: RevenueCatData,
    type: PurchaseType = PURCHASE_TYPE.INITIAL
  ): Promise<CreditsResult> {
    const db = requireFirestore();
    return initializeCreditsWithRetry({
      db,
      ref: this.getRef(db, userId),
      config: this.config,
      userId,
      purchaseId,
      productId,
      source,
      revenueCatData,
      type,
    });
  }

  async deductCredit(userId: string, cost: number): Promise<DeductCreditsResult> {
    const db = requireFirestore();
    return deductCreditsOperation(db, this.getRef(db, userId), cost, userId);
  }

  async refundCredit(userId: string, amount: number): Promise<DeductCreditsResult> {
    const db = requireFirestore();
    return refundCreditsOperation(db, this.getRef(db, userId), amount, userId);
  }

  async hasCredits(userId: string, cost: number): Promise<boolean> {
    const db = requireFirestore();
    return checkHasCredits(this.getRef(db, userId), cost);
  }

  async creditsDocumentExists(userId: string): Promise<boolean> {
    const db = requireFirestore();
    return documentExists(this.getRef(db, userId));
  }

  async syncExpiredStatus(userId: string): Promise<void> {
    const db = requireFirestore();
    await syncExpiredStatus(this.getRef(db, userId));
  }

  async syncPremiumMetadata(userId: string, metadata: SubscriptionMetadata): Promise<void> {
    const db = requireFirestore();
    await syncPremiumMetadata(this.getRef(db, userId), metadata);
  }

  async ensurePremiumCreditsExist(
    userId: string,
    productId: string,
    willRenew: boolean,
    expirationDate: string | null,
    periodType: string | null,
    _storeTransactionId?: string | null,
  ): Promise<boolean> {
    const db = requireFirestore();
    const creditLimit = this.creditLimitService.calculate(productId);
    return createRecoveryCreditsDocument(
      this.getRef(db, userId),
      creditLimit,
      productId,
      willRenew,
      expirationDate,
      periodType,
    );
  }
}

export function createCreditsRepository(config: CreditsConfig): CreditsRepository {
  return new CreditsRepository(config);
}
